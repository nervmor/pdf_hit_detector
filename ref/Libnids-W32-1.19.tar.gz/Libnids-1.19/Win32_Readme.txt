/*
 *       __                     __                                                
 *      /\ \                   /\ \                                               
 *   ___\ \ \___      __    ___\ \ \/'\     ____  __  __    ___ ___         ___    _ __    __  
 *  /'___\ \  _ `\  /'__`\ /'___\ \ , <    /',__\/\ \/\ \ /' __` __`\      / __`\ /\`'__\/'_ `\   
 * /\ \__/\ \ \ \ \/\  __//\ \__/\ \ \\`\ /\__, `\ \ \_\ \/\ \/\ \/\ \  __/\ \L\ \\ \ \//\ \L\ \ 
 * \ \____\\ \_\ \_\ \____\ \____\\ \_\ \_\/\____/\ \____/\ \_\ \_\ \_\/\_\ \____/ \ \_\\ \____ \ 
 *  \/____/ \/_/\/_/\/____/\/____/ \/_/\/_/\/___/  \/___/  \/_/\/_/\/_/\/_/\/___/   \/_/ \/___L\ \
 *                                                                                         /\____/
 *                                                                                         \_/__/ 
 *
 *
 *           _\|/_
 *           (o o)
 *   +----oOO-{_}-OOo---------------------+
 *   |                                    |
 *   | different people,                  |
 *   |   different knowledge,             |
 *   |     same interest                  |
 *   +------------------------------------+
 *   Copyright � 1999-2004 checksum.org.
 *
 *   Libnids is licensed under GPL. See the file COPYING for details.
 *
 */

---=[:Updates:]=--------

Thanks to Nergal (at) avnet (dot) com (dot) pl, the creator of Libnids,
for the info. This release contains Libnids v 1.19. Please check the changes 
file to know more

---=[:Greets:]=--------

To All Checksum members and to people out there.
You know who you are!! ;-)

---=[:Comments:]=--------

Great Work Mike. Without your initial work this would have been a tough task
Greets to others who *still* want to work on Windows with base linux and *nix
software ;-)

---=[:C/C/C:]=--------

Comments/Cribs/Critics ==> goldie (at) checksum (dot) org

---=[:WARNING!:]=--------

Has been tested under Windows NT/2000 With Visual Studio 6.0 with Service Pack 5
and WinPcap 3.0 with NT SP6a and W2K SP2. If you find any bugs or patches, please
send it to the above address.

---=[:Todo:]=--------

To create a NDIS driver of Libnids.

---=[:QUOTE:]=--------

Miles to go before i sleep

---=[:*:]=--------
